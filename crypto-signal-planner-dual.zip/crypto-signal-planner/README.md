# Crypto Signal Planner — shared AgentSkills skill

One portable `SKILL.md` for **OpenClaw and Codex**, distilled from a repeatable workflow: recommend a **new non-duplicate** cryptocurrency, independently verify the ticker/chain/current market, test the fundamental catalyst and trading structure, and produce a **conditional spot** trading plan with a risk-first position sizing calculation. RENDER is included only as a historical example of the workflow.

> This is a research/signal skill, **not** a deployed scanner, trading bot, scheduler, data provider, or brokerage integration. It produces **no order and no fill**. Live screening needs network/research tools available to the host agent. Its Python calculators are deterministic and offline.

## Contents
- `SKILL.md`: installable skill instructions with YAML frontmatter
- `references/market-evidence.md`: fresh-quote, token identity and official-source rules
- `references/strategy-policy.md`: screening, entry/exit and risk budget logic
- `assets/response-template.md`: reusable Chinese answer format
- `scripts/position_size.py`: standard-library risk sizing + cost-adjusted first-target R:R
- `scripts/validate_plan.py`: basic integrity/evidence staleness gate for JSON plans
- `scripts/smoke_test.py`: offline unit-style tests
- `examples/render-case.md`: previous RENDER idea labeled **historical**
- `examples/hypothetical-plan.json`: illustrative fixture, never a current market plan
- `install.sh`: local, non-overwriting copier

## Minimum requirements
- OpenClaw and/or Codex already installed
- Python 3.9+ for the optional helper scripts; the SKILL.md alone works without Python
- For actionable source-backed analyses: host agent must have authorized web / market data access
- No secrets, API keys, exchange keys or pip dependencies needed for the bundled skill

## Install on macOS/Linux/WSL
Unzip the archive and enter its extracted outer folder. **Default one-copy option:**

```bash
bash crypto-signal-planner/install.sh shared
```

This writes `~/.agents/skills/crypto-signal-planner`, scanned by **Codex** and by **default-local-state OpenClaw**. If OpenClaw uses a custom `OPENCLAW_STATE_DIR`, install it to its current state/workspace instead.

**OpenClaw explicit:**

```bash
# Using OpenClaw's native CLI (preferred when connected to the right Gateway):
openclaw skills install ./crypto-signal-planner --as crypto-signal-planner
openclaw skills info crypto-signal-planner
openclaw skills check

# OR directly to its default managed/local directory:
bash crypto-signal-planner/install.sh openclaw
# OR set workspace explicitly, if non-default:
OPENCLAW_WORKSPACE="$HOME/.openclaw/workspace" bash crypto-signal-planner/install.sh openclaw-workspace
```

Do not install using both the shared path and the OpenClaw explicit path on the same agent unless you deliberately want precedence/collision behavior. Current OpenClaw docs: https://docs.openclaw.ai/tools/skills and https://docs.openclaw.ai/cli/skills

**Codex explicit:**

```bash
bash crypto-signal-planner/install.sh codex
# Or, from the extracted outer folder, repo-only:
mkdir -p /PATH/TO/REPO/.agents/skills
cp -R crypto-signal-planner /PATH/TO/REPO/.agents/skills/
```

Current Codex docs: https://learn.chatgpt.com/docs/build-skills

## Test offline
```bash
python3 crypto-signal-planner/scripts/smoke_test.py
python3 crypto-signal-planner/scripts/position_size.py \
  --equity 100000 --entry 10 --stop 9 --target 12.3 \
  --risk-pct 0.005 --allocation-pct 0.05
python3 crypto-signal-planner/scripts/validate_plan.py \
  crypto-signal-planner/examples/hypothetical-plan.json --allow-fixture
```

**Important:** `--allow-fixture` bypasses ONLY the illustrative-plan block to allow offline testing. Do not use it to validate investment recommendations. Normal validation intentionally fails on the bundled fictional example.

## Invoke
- OpenClaw chat: `/crypto-signal-planner 再推荐一个币，排除 SOL、SUI、LINK、AAVE、ONDO、RENDER，只做现货` or just ask if implicit matching is enabled.
- Codex CLI/IDE: `$crypto-signal-planner 分析 RENDER，先验证最新链和交易对，数据不足就不要给买入价`.
- For integrating with BTC Quant AI: ask the host to use this skill to generate **paper-only** candidate JSON and compare persistent model state; actual scheduling/notifications/broker interactions must be built or authorized separately.

## How to assess installation
- OpenClaw: run `openclaw skills list --eligible`, `openclaw skills info crypto-signal-planner`, then invoke `/crypto-signal-planner` in a **new session** when necessary.
- Codex: restart if required, run `/skills` or type `$crypto-signal-planner`.
- If shared path does not appear in OpenClaw due to custom Gateway/state, install in the agent's configured `<workspace>/skills` or managed state `skills` root and check the connected Gateway's inventory.

## Security / limitations
All bundled scripts are Python standard library and have **zero network calls** and **zero trading integration**. A web-enabled agent still needs explicit permission according to its host runtime. Only attach external-market claims after checking time, primary sources, and instrument identity. Stop levels do not guarantee fills; example prices are not present-time advice.
