# 双平台安装速查：OpenClaw / Codex

本包将“反重复选币 → 最新行情核验 → 官方催化 → 风险评分 → 条件入场/止盈/失效 → 仓位计算 → 信号去重”蒸馏为一个 `crypto-signal-planner` Skill。包含 RENDER 历史示例，但不会硬编码任何历史行情作为当日买价。

## 1. 解压
```bash
unzip crypto-signal-planner-dual.zip -d ~/crypto-skill-release
cd ~/crypto-skill-release
```

## 2. 同机同时用于 OpenClaw 与 Codex（默认本地安装）
```bash
bash crypto-signal-planner/install.sh shared
```
默认复制到 `~/.agents/skills/crypto-signal-planner/`，两个工具的默认本地模式均可发现此路径。

## 3. 如果只装 OpenClaw（或自定义 Gateway）
```bash
# 在解压后的文件夹运行：
openclaw skills install ./crypto-signal-planner --as crypto-signal-planner
openclaw skills info crypto-signal-planner
openclaw skills check
```
也可以把包复制到 **实际 OpenClaw agent 的** `<workspace>/skills/crypto-signal-planner`，不要盲目把文件放到与所连远端 Gateway 无关的本机。

## 4. 如果只装 Codex
```bash
bash crypto-signal-planner/install.sh codex
```
重新打开 Codex（必要时），输入 `/skills` 查看，再通过 `$crypto-signal-planner` 显式调用。

## 5. 测试
```bash
python3 crypto-signal-planner/scripts/smoke_test.py
```
输出 `PASS` 只说明**离线计算和规则校验**通过，绝不是历史回测、在线行情验证、推送或实盘已接通。

## 6. 调用例子
- OpenClaw：`/crypto-signal-planner 再推荐一个币，不要和SOL/SUI/LINK/AAVE/ONDO/RENDER重复，给现货分批计划`
- Codex：`$crypto-signal-planner 分析RENDER，检查最新行情、正确网络和交易对，计算含费用的仓位与R:R；无足够证据则NO_ACTION`

## 7. 安全边界
没有账号密钥、网络请求脚本、交易所下单代码或收益保证。任何交易动作都是“待条件触发的研究信号”；即使验证脚本通过，也不能据此声称已下单。安装脚本碰到同名目录会停止，不会覆盖已有修改。

官方参考：OpenClaw https://docs.openclaw.ai/tools/skills；Codex https://learn.chatgpt.com/docs/build-skills
